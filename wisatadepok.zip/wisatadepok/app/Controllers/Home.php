<?php

namespace App\Controllers;
// namespace App\Controllers\PageNotFoundException;

use App\Models\WisataModel;
use App\Models\JenisModel;
use App\Models\KecamatanModel;
use App\Models\UsersModel;
use App\Models\KomentarModel;
use PHPUnit\Framework\MockObject\Stub\ReturnRefere;


class Home extends BaseController
{
    protected $WisataModel;
    protected $JenisModel;
    protected $KecamatanModel;
    protected $UsersModel;
    protected $KomentarModel;
    public function __construct()
    {
        $this->wisataModel = new WisataModel();
        $this->JenisModel = new JenisModel();
        $this->KecamatanModel = new KecamatanModel();
        $this->UsersModel = new UsersModel();
        $this->KomentarModel = new KomentarModel();
    }

    public function index()
    {
        $wisata = $this->wisataModel->findAll();
        $data = [
            'wisata' => $wisata,
        ];

        return view('index', $data);
    }

    public function admin()
    {
        return view('/admin/index.php');
    }
    public function kelola_wisata()
    {
        $wisata = $this->wisataModel->findAll();

        $data = [
            'wisata' => $wisata,
        ];
        return view('/admin/kelola_wisata', $data);
    }
    public function create()
    {
        $jenis = $this->JenisModel->findAll();
        $kecamatan = $this->KecamatanModel->findAll();
        return view('/admin/create', compact(['jenis', 'kecamatan']));
    }

    public function save_wisata()
    {

        $this->wisataModel->save([
            'nama' => $this->request->getVar('nama'),
            'deskripsi' => $this->request->getVar('deskripsi'),
            'alamat' => $this->request->getVar('alamat'),
            'latlong' => $this->request->getVar('latlong'),
            'harga_tiket' => $this->request->getVar('harga_tiket'),
            'foto1' => $this->request->getVar('foto1'),
            'foto2' => $this->request->getVar('foto2'),
            'foto3' => $this->request->getVar('foto3'),
            'website' => $this->request->getVar('website'),
            'jenis_id' => $this->request->getVar('jenis'),
            'kecamatan_id' => $this->request->getVar('kecamatan'),
            'fasilitas' => $this->request->getVar('fasilitas')

        ]);
        return redirect()->to('home/kelola_wisata');
    }

    public function delete($id)
    {
        $model = new WisataModel();
        $model->delete($id);
        return redirect()->to('home/kelola_wisata');
    }



    public function update($id)
    {
        $model = new WisataModel();
        $update = $model->find($id);

        $data = [
            'update' => $update
        ];
        return view('admin/update', $data);
    }

    public function detail($id)
    {

        $model = new WisataModel();
        $detail = $model->find($id);

        $data = [
            'detail' => $detail
        ];
        return view('detail', $data);
    }

    public function kelola_user()
    {
        $users = $this->UsersModel->findAll();
        $data = [
            'users' => $users,
        ];
        return view('admin/kelola_user', $data);
    }

    public function delete_user($id)
    {
        $model = new UsersModel();
        $model->delete($id);
        return redirect()->to('home/kelola_user');
    }
    public function kelola_komentar()
    {
        $komentar = $this->KomentarModel->findAll();
        $data = [
            'komentar' => $komentar,
        ];
        return view('admin/kelola_komentar', $data);
    }
    public function delete_komentar($id)
    {
        $model = new KomentarModel();
        $model->delete($id);
        return redirect()->to('home/kelola_komentar');
    }


    public function daftar_akun()
    {
        return view('daftar_akun');
    }






    public function user()
    {
        return view('/login.php');
    }
}
