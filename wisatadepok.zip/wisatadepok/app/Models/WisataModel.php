<?php

namespace App\Models;

use CodeIgniter\Model;

class WisataModel extends Model
{
    protected $table = 'tempat_wisata';
    protected $allowedFields = ['nama', 'latlong', 'foto1', 'foto2', 'foto3', 'jenis_id', 'kecamatan_id', 'deskripsi', 'alamat', 'harga_tiket', 'foto1', 'website', 'fasilitas'];

    protected $primaryKey = 'id';
}
