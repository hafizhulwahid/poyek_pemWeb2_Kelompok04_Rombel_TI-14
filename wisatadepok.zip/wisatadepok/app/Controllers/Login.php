<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UsersModel;

class Login extends BaseController
{
    protected $UsersModel;

    public function __construct()
    {
        $this->users = new UsersModel();
    }

    public function Auth()
    {

        $data = $this->request->getPost();
        $user = $this->users->where('email', $data['email'])->first();
        if ($user) {
            if ($user['password'] == md5($data['password'])) {
                session()->set('username', $user['username']);
                session()->set('id', $user['id']);
                session()->set('role', $user['role']);
                session()->set('status', $user['status']);
                session()->set('last_login', $user['last_login']);
                session()->set('created_at', $user['created_at']);
                session()->set('islogin', true);
                $this->session->setFlashdata('success', "Successfully logged in.");
                if ($user['role'] == 'administrator') {
                    return redirect()->to('admin/index');
                } else {
                    return redirect()->to('');
                }
            } else {
                $this->session->setFlashdata('error', "Invalid Credential");
                return redirect()->to('');
            }
        } else {
            $this->session->setFlashdata('error', "Invalid Credential");
            return redirect()->to('');
        }
    }


    public function logout()
    {
        session()->destroy();
        return redirect()->to('');
    }

    public function register()
    {

        return view('/auth/registered');
    }

    public function registered()
    {
        $data = $this->request->getPost();
        $username_email = explode('@', $data['email']);
        $username = $username_email[0];
        $email = $data['email'];
        $created_at = date('Y-m-d H:i:s');
        $status = 1;
        $role = 'public';
        $password = md5($data['password']);

        $this->users->insert([
            'username' => $username,
            'email' => $email,
            'password' => $password,
            'created_at' => $created_at,
            'status' => $status,
            'role' => $role
        ]);


        return redirect()->to('');
    }
}
