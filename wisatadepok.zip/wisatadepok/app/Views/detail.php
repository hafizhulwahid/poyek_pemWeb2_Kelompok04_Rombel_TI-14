<!DOCTYPE html>
<html>
<style>
    /* Clearfix */
    .clearfix:before,
    .clearfix:after {
        content: " ";
        display: table;
    }

    .clearfix:after {
        clear: both;
    }

    .clearfix {
        *zoom: 1;
    }

    /******************************************************/
    /******************** Desain Menu *********************/
    /******************************************************/
    body {
        background-color: grey;
    }

    nav {
        height: 70px;
        width: 100%;
        background: white;
        font-size: 11pt;
        font-family: 'PT Sans', Arial, sans-serif;
        font-weight: bold;

    }

    nav ul {
        padding: 0;
        margin: 0 auto;
        width: 500px;
        height: 40px;
    }

    nav li {
        display: inline;
        float: left;

    }

    nav a {
        color: grey;
        display: inline-block;
        width: 100px;
        text-align: center;
        text-decoration: none;
        line-height: 70px;
    }

    nav a:hover,
    nav a:active {
        background-color: #ecf0f1;
        color: #333;
    }

    nav a#pull {
        display: none;
    }


    /******************************************************/
    /*************** Desain Menu Responsive ***************/
    /******************************************************/

    /* Desain untuk perangkat dengan layar 600px kebawah*/
    @media screen and (max-width: 600px) {
        nav {
            height: auto;
            border-bottom: 0;
            background: white;
            text-align: center;
        }

        nav ul {
            width: 100%;
            display: none;
            height: auto;
        }

        nav li {
            width: 100%;
            float: none;
            display: block;
            background: #ffffff;
        }

        nav li a {
            border-bottom: 1px solid #f0f0f0;
            border-right: 1px solid #f0f0f0;
        }

        nav a {
            text-align: left;
            width: 100%;
            text-indent: 25px;
            color: #333333;
        }

        nav a#pull {
            display: block;
            background-color: #3498db;
            width: 100%;
            position: relative;
            color: #ffffff;
        }

        nav a#pull:after {
            content: "";
            background: url('nav-icon.png') no-repeat;
            width: 30px;
            height: 30px;
            display: inline-block;
            position: absolute;
            right: 15px;
            top: 10px;
        }
    }


    .container.gallery-container {
        background-color: #fff;
        color: #35373a;
        min-height: 100vh;
        padding: 30px 50px;
    }

    .gallery-container h1 {
        text-align: center;
        margin-top: 50px;
        font-family: 'Droid Sans', sans-serif;
        font-weight: bold;
    }

    .gallery-container p.page-description {
        text-align: center;
        margin: 25px auto;
        font-size: 18px;
        color: #999;
    }

    .tz-gallery {
        padding: 40px;
    }

    /* Override bootstrap column paddings */
    .tz-gallery .row>div {
        padding: 2px;
    }

    .tz-gallery .lightbox img {
        width: 100%;
        border-radius: 0;
        position: relative;
    }

    .tz-gallery .lightbox:before {
        position: absolute;
        top: 50%;
        left: 50%;
        margin-top: -13px;
        margin-left: -13px;
        opacity: 0;
        color: #fff;
        font-size: 26px;
        font-family: 'Glyphicons Halflings';
        content: '\e003';
        pointer-events: none;
        z-index: 9000;
        transition: 0.4s;
    }


    .tz-gallery .lightbox:after {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        background-color: rgba(46, 132, 206, 0.7);
        content: '';
        transition: 0.4s;
    }

    .tz-gallery .lightbox:hover:after,
    .tz-gallery .lightbox:hover:before {
        opacity: 1;
    }

    .baguetteBox-button {
        background-color: transparent !important;
    }

    @media(max-width: 768px) {
        body {
            padding: 0;
        }
    }
</style>

<head>
    <title>Detail Wisata Depok</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/plugins/summernote/summernote-bs4.min.css">
    <link rel="stylesheet" href="style.css">
    <link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
    <script>
        $(function() {
            var pull = $('#pull'); // Variabel tombol navigasi (akan muncul hanya pada perangkat mobile)
            menu = $('nav ul'); // Variabel menu

            $(pull).on('click', function(e) {
                e.preventDefault();
                menu.slideToggle();
            });
            $(window).resize(function() {
                var w = $(window).width();
                if (w > 600 && menu.is(':hidden')) {
                    menu.removeAttr('style');
                }
            });
        });
    </script>
</head>

<body>
    <nav class="clearfix">
        <a href="#" id="pull">Menu</a>
        <ul class="clearfix">
            <li></li>
            <li><a href="/">Beranda</a></li>
            <li><a href="/#about">About</a></li>
            <li><a href="/#contac">Contac</a></li>
        </ul>

    </nav>

    <section>
        <div class="jumbotron">
            <h3>Detail Wisata <?= $detail['nama']; ?></h3>
            <div class="tz-gallery">

                <div class="row">

                    <div class="col-sm-12 col-md-4">
                        <a class="lightbox" href="<?= base_url('/assets/img/wisata/' . $detail['foto1']); ?>">
                            <img class="card-img-top" src="<?= base_url('/assets/img/wisata/' . $detail['foto1']); ?>" alt="Card image cap">
                        </a>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <a class="lightbox" href="<?= base_url('/assets/img/wisata/' . $detail['foto2']); ?>">
                            <img class="card-img-top" src="<?= base_url('/assets/img/wisata/' . $detail['foto2']); ?>" alt="Card image cap">
                        </a>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <a class="lightbox" href="<?= base_url('/assets/img/wisata/' . $detail['foto3']); ?>">
                            <img class="card-img-top" src="<?= base_url('/assets/img/wisata/' . $detail['foto3']); ?>" style: width="300px;height: 150px; alt=" Card image cap">
                        </a>
                    </div>
                    <div>
                        <p><?= $detail['deskripsi']; ?></p>
                        <p>Alamat : <?= $detail['alamat']; ?></p>
                        <p>Harga Tiket : Rp.<?= $detail['harga_tiket']; ?></p>
                        <p>Fasilitas : <?= $detail['fasilitas']; ?></p>
                        <small><?= $detail['website']; ?></small>
                    </div>

                </div>

            </div>







            <div class="jumbotron">
                <h3>Komentar Tentang <?= $detail['nama']; ?></h3>
                <hr>
                <div class="row">

                    <div class="col-sm-6">
                        <table>
                            <tr>
                                <td><img src="<?= base_url('assets') ?>/img/wisata/logo.png" class="img-circle elevation-2" alt="User Image" height="60" width="60"></td>
                                <td>
                                    <b style="margin-left: 10px;">Anonymous</b>
                                    <br>
                                    <small style="margin-left: 10px;">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quis asperiores autem quos nemo et. Quis, excepturi mollitia iure eos quam</small>
                                </td>
                            </tr>
                        </table>
                    </div>


                </div>
                <br><br>
                <div class="col-sm-6">
                    <form action="/home/save_komentar">
                        <div class="form-group">

                            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="......" size="30">
                            <br>
                            <button type="submit" class="btn btn-info">Masukkan Komentar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        </div>
    </section>

    <footer id="footer" class="footer" style="background-color: black;padding: 10px;color: white;">

        <div class="container">
            <div class="row gy-3">
                <div class="col-lg-3 col-md-6 d-flex">
                    <i class="bi bi-geo-alt icon"></i>
                    <div>
                        <h4>Address</h4>
                        <p>
                            A108 Adam Street <br>
                            New York, NY 535022 - US<br>
                        </p>
                    </div>

                </div>

                <div class="col-lg-3 col-md-6 footer-links d-flex">
                    <i class="bi bi-telephone icon"></i>
                    <div>
                        <h4>Reservations</h4>
                        <p>
                            <strong>Phone:</strong> +1 5589 55488 55<br>
                            <strong>Email:</strong> info@example.com<br>
                        </p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 footer-links d-flex">
                    <i class="bi bi-clock icon"></i>
                    <div>
                        <h4>Opening Hours</h4>
                        <p>
                            <strong>Mon-Sat: 11AM</strong> - 23PM<br>
                            Sunday: Closed
                        </p>
                    </div>
                </div>

            </div>
            <hr>
            <div class="container" style="text-align: center;border-top: 1px solid grey;">
                <div class="copyright">
                    &copy; Copyright <strong><span>Wisata Depok</span></strong>. All Rights Reserved
                </div>
                <div class="credits">
                    <!-- All the links in the footer should remain intact. -->
                    <!-- You can delete the links only if you purchased the pro version. -->
                    <!-- Licensing information: https://bootstrapmade.com/license/ -->
                    <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/yummy-bootstrap-restaurant-website-template/ -->
                    Designed by Kelompok Project Pemrograman Web</a>
                </div>
            </div>

    </footer><!-- End Footer -->
</body>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>

</html>